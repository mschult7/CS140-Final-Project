package project;

import java.util.IllegalFormatFlagsException;

public class ParityCheckException extends IllegalFormatFlagsException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ParityCheckException(String f) {
		super(f);
		// TODO Auto-generated constructor stub
	}

}
