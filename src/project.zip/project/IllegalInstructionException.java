package project;

public class IllegalInstructionException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IllegalInstructionException(String f) {
		// TODO Auto-generated constructor stub
		super(f);
	}


}
